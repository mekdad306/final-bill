// Current date & time display (you can place this in any page or add an element with id="dateTime")
function updateDateTime() {
  const now = new Date();
  const formatted = now.toLocaleString();
  const dateTimeEl = document.getElementById('dateTime');
  if (dateTimeEl) {
    dateTimeEl.textContent = formatted;
  }
}
setInterval(updateDateTime, 1000);
updateDateTime();

// Contact form validation & submission confirmation
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('contactForm');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();

      // Simple email validation
      const email = document.getElementById('email');
      const mobile = document.getElementById('mobile');
      let valid = true;

      if (!email.value.match(/^\S+@\S+\.\S+$/)) {
        email.classList.add('is-invalid');
        valid = false;
      } else {
        email.classList.remove('is-invalid');
      }

      // Mobile number validation: digits only and length == 11
      if (!/^\d{11}$/.test(mobile.value)) {
        mobile.classList.add('is-invalid');
        valid = false;
      } else {
        mobile.classList.remove('is-invalid');
      }

      // Name required
      const name = document.getElementById('name');
      if (name.value.trim() === '') {
        name.classList.add('is-invalid');
        valid = false;
      } else {
        name.classList.remove('is-invalid');
      }

      if (!valid) return;

      // Confirmation popup
      if (confirm('Do you want to submit the form?')) {
        alert('Form submitted successfully!');
        form.reset();
      }
    });
  }
});




